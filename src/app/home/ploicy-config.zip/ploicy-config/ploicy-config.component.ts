import { Component, OnInit } from '@angular/core';
import { GeneralService } from '../../general.service';

@Component({
  selector: 'app-ploicy-config',
  templateUrl: './ploicy-config.component.html',
  styleUrls: ['./ploicy-config.component.css']
})
export class PloicyConfigComponent implements OnInit {
  policy: Boolean = true;
  compilance: Boolean = false;
  showwalletfield: Boolean = false;
  showipaddress: Boolean = false;
  ipaddresslist: any = [];
  walletaddress: any = [];
  policylist: any = [];
  walletaddresslist: any = [];
  policyType: any = '';
  obj: any = {
    'WalletAddressWhitelist' : [],
    'TransactionLimit': '',
    'TransactionUnitOfMeasure': '',
    'MinimumBalance': '',
    'TransactionVolumeCap': '' ,
    'TransactionTimeStart': '',
    'TransactionTimeEnd': '',
   };
  constructor(private generalservice: GeneralService) { }

  ngOnInit() {
    this.loadpolicies();
  }
  showpolicyconfig() {
    this.policy = true;
    this.compilance = false;
  }
  addipaddress() {
    this.showipaddress = true;
  }
addwalletaddress() {
this. showwalletfield = true;
this.walletaddress.push();
}
removewalletaddress() {
}
removeipaddress() {
}

loadpolicies() {
const obj = {
  'userId' : 8
};
const url = 'wallet/get-policy';
this.generalservice.generalServiceInfo(url, 'post', obj)
                    .subscribe(
                      res => {
                        this.policylist = res['data'];
                        console.log(this.policylist);
                        this.walletaddresslist = this.policylist['WalletAddressWhitelist'];
                        this.policyType = this.walletaddresslist.UserType;
                      },
                      e => {
                      },
                      () => {
                      }
                    );

}
updatedetails() {
console.log(this.policylist);
}
}
